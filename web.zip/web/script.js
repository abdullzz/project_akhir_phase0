function change_theme(colors)
{
    document.getElementsByClassName('button').style.background = colors
}